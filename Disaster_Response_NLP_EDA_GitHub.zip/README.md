# Disaster Response — NLP EDA Engineer

## Role
**EDA Engineer:** Analyze vocabulary distributions and phrasing patterns across urgent vs routine disaster reports.

## Objective
This EDA supports the NLP part of the autonomous disaster-response multi-agent system. The goal is to understand what language appears in disaster-relevant and non-relevant messages, identify urgency-related phrasing, detect data-quality/leakage risks, and give the ML/DL team evidence for preprocessing and evaluation.

## Dataset
- Master dataset: **17,170 rows**
- Focused task: `disaster_relevance_classification`
- Focused rows: **6,874**
- Text field: `text_clean`

## EDA Pipeline
```text
Master Disaster Dataset
        ↓
Select NLP Task
        ↓
Missing + Duplicate Checks
        ↓
Text Length Analysis
        ↓
Overall Vocabulary
        ↓
Label-wise Vocabulary
        ↓
Urgent vs Routine Phrasing
        ↓
Class Imbalance
        ↓
Leakage Check
        ↓
Preprocessing Recommendations
        ↓
ML / DL Modeling
```

## Key Results
| Metric | Result |
|---|---:|
| Master rows | 17,170 |
| Relevance-task rows | 6,874 |
| Missing cells in focused task | 43,561 |
| Duplicate rows | 0 |
| Mean words/report | 14.94 |
| Median words/report | 15 |
| Maximum words/report | 31 |

## Vocabulary Analysis
Vocabulary is analyzed overall and separately by label. This prevents common disaster words from hiding differences between message classes.

### Urgent-style indicators checked
`emergency`, `help`, `trapped`, `rescue`, `evacuate`, `missing`, `injured`, `danger`, `stranded`, `hospital`, `collapse`, `flood`, `casualties`, `warning`, `critical`

### Routine/information-style indicators checked
`update`, `information`, `report`, `news`, `situation`, `forecast`, `weather`, `details`, `official`, `confirmed`, `announcement`, `latest`, `status`

**Note:** these are EDA heuristics, not the final classifier. They are used to discover patterns and guide feature engineering.

## Why This Matters
```text
"People are trapped. Need rescue immediately."
                    ↓
        Urgency-related language
                    ↓
            NLP risk signal
                    ↓
         Triage / rescue agent
                    ↓
  Combine with sensor + CNN + LSTM evidence
```
The NLP model should provide evidence; it should not make a rescue decision from keywords alone.

## Leakage Checks
Do not use these as predictive features when they reveal the target or dataset identity:
- `label`
- `label_values_json`
- `extracted_phrase`
- `entities_json`
- `relations_json`
- `record_id`, `source_row_id`, `source_file`
- event identifiers if they leak the disaster identity

Also check normalized-text/near-duplicate overlap between splits and prefer event-aware testing for a strong generalization test.

## Preprocessing Recommendations
1. Use `text_clean` as the modeling input.
2. Preserve `<URL>` / `<USER>` placeholders rather than raw identifiers.
3. Preserve useful hashtags unless experiments show leakage.
4. Use task-specific label encoding.
5. For TF-IDF: `fit_transform()` on training data; `transform()` on validation/test.
6. Use macro-F1, per-class recall, precision and confusion matrix rather than accuracy alone.
7. Inspect false negatives because missed emergency messages can be operationally important.

## Files
```text
eda_engineer_nlp.py
README.md
outputs/
├── eda_summary.csv
├── label_distribution.png
├── text_length_distribution.png
├── top_vocabulary.png
├── top_words_label_*.png
├── phrasing_summary.csv
├── urgent_phrasing_examples.csv
└── routine_phrasing_examples.csv
```

## Run
```bash
pip install pandas numpy matplotlib
python eda_engineer_nlp.py --input master_training.csv --output outputs
```

## What I Did as EDA Engineer
1. Validated the NLP task and schema.
2. Checked missing values and duplicates.
3. Analyzed text length and vocabulary distributions.
4. Compared vocabulary by label.
5. Built urgency/routine phrasing indicators for exploratory analysis.
6. Checked class distribution.
7. Identified possible target/data leakage fields.
8. Recommended preprocessing and evaluation methods for the ML/DL engineers.

## Viva Answer
**Q: What did you do as an EDA Engineer?**

> I analyzed the disaster NLP dataset to understand data quality, vocabulary distribution and phrasing patterns across message classes. I checked missing values, duplicates, text length and class imbalance. I compared class-wise vocabulary and identified urgency-related terms such as rescue, trapped, injured and emergency, along with routine information patterns. I also checked potential leakage and converted the findings into preprocessing and evaluation recommendations for the ML/DL team.
