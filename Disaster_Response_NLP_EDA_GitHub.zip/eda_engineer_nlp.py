"""Disaster Response NLP — EDA Engineer
Analyze vocabulary distributions and phrasing patterns across disaster-relevant vs non-relevant reports.
Run: python eda_engineer_nlp.py --input master_training.csv --output outputs
"""
import argparse, os, re
from collections import Counter
import pandas as pd
import matplotlib.pyplot as plt
URGENT_TERMS=['urgent','emergency','help','trapped','rescue','evacuate','evacuation','missing','injured','injury','danger','dangerous','stranded','need help','sos','hospital','collapse','collapsed','flood','flooded','fire','casualties','dead','death','victim','warning','critical']
ROUTINE_TERMS=['update','information','report','reported','news','situation','forecast','weather','details','official','confirmed','announcement','latest','status']
STOPWORDS=set('a an the and or but if then than is are was were be been being to of in on for from with at by as it this that these those i you he she we they them his her our their my your me us not no do does did has have had can could will would should may might'.split())
def tokens(text): return re.findall(r"[a-zA-Z][a-zA-Z'-]{1,}",str(text).lower())
def hits(text,terms):
 text=str(text).lower(); return sum(len(re.findall(r'\b'+re.escape(x)+r'\b',text)) for x in terms)
def top_words(series,n=20):
 c=Counter()
 for text in series: c.update(w for w in tokens(text) if w not in STOPWORDS)
 return c.most_common(n)
def save_bar(items,title,path):
 labs=[x[0] for x in items]; vals=[x[1] for x in items]
 plt.figure(figsize=(9,5)); plt.barh(labs[::-1],vals[::-1]); plt.title(title); plt.xlabel('Frequency'); plt.tight_layout(); plt.savefig(path,dpi=180); plt.close()
def main():
 p=argparse.ArgumentParser(); p.add_argument('--input',required=True); p.add_argument('--output',default='outputs'); a=p.parse_args(); os.makedirs(a.output,exist_ok=True)
 df=pd.read_csv(a.input,low_memory=False)
 data=df[df['source_task'].eq('disaster_relevance_classification')].copy() if 'source_task' in df.columns else df.copy()
 data['text_clean']=data['text_clean'].fillna('').astype(str); data['word_count']=data.text_clean.str.split().str.len(); data['char_count']=data.text_clean.str.len()
 data['urgent_keyword_hits']=data.text_clean.map(lambda x:hits(x,URGENT_TERMS)); data['routine_keyword_hits']=data.text_clean.map(lambda x:hits(x,ROUTINE_TERMS))
 pd.DataFrame([{'rows':len(data),'columns':len(data.columns),'missing_cells':int(data.isna().sum().sum()),'duplicate_rows':int(data.duplicated().sum()),'average_words':data.word_count.mean(),'median_words':data.word_count.median(),'maximum_words':data.word_count.max()}]).to_csv(os.path.join(a.output,'eda_summary.csv'),index=False)
 data.label.value_counts().sort_index().plot(kind='bar',figsize=(6,4)); plt.title('Disaster Relevance Label Distribution'); plt.xlabel('Label'); plt.ylabel('Records'); plt.tight_layout(); plt.savefig(os.path.join(a.output,'label_distribution.png'),dpi=180); plt.close()
 plt.figure(figsize=(8,5)); plt.hist(data.word_count,bins=35); plt.title('Text Length Distribution'); plt.xlabel('Words per report'); plt.ylabel('Records'); plt.tight_layout(); plt.savefig(os.path.join(a.output,'text_length_distribution.png'),dpi=180); plt.close()
 save_bar(top_words(data.text_clean,30),'Top Disaster Vocabulary',os.path.join(a.output,'top_vocabulary.png'))
 for lab,g in data.groupby('label'): save_bar(top_words(g.text_clean,20),f'Top Vocabulary — Label {lab}',os.path.join(a.output,f'top_words_label_{lab}.png'))
 data.groupby('label')[['urgent_keyword_hits','routine_keyword_hits']].agg(['mean','sum']).to_csv(os.path.join(a.output,'phrasing_summary.csv'))
 print('EDA completed:',len(data),'rows')
if __name__=='__main__': main()
